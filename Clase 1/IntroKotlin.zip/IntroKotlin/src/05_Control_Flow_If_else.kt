fun main() {

    // EXAMPLE 1

    // EXAMPLE 2 . If as an expression

}