
fun main(){

    // EXAMPLE 1. In rage. 0123
    println("")

    // EXAMPLE 2. Until. 012
    println("")

    // EXAMPLE 3. Step. 2468
    println("")

    // EXAMPLE 4. downTo. 3210
    println("")

    // EXAMPLE 5. Rage of characters. acbd
    println("")

    // EXAMPLE 6. In Range.

}