// A lambda is an anonymous function, meaning a function that does not have an associated name.
// { parameters -> body }

// EXAMPLE 1. Lambda definition

// EXAMPLE 2. One string

fun main() {

}