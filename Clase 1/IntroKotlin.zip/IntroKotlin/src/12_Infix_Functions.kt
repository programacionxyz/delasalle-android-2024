// Have a single parameter
// Infix keyword
// It gives us the ability to use functions as if they were arithmetic operators.


class Label(var content:String)

fun main() {

    // Example 1 : Pair<A,B>

    // Example 2 : Until


    // Custom Example 1


    // Custom Example 2

}