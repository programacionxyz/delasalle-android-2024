fun main() {
    // EXAMPLE 1. Immutable


    // EXAMPLE 2. Mutable


}