// 1) Receive functions as parameters: They can take functions as arguments.
// 2) Return functions: They can return a function as a result.
// 3) Conciseness: They allow writing more concise code, especially when working with repetitive
//    operations or dynamic actions.

// EXAMPLE 1. Receive function as a parameter


// EXAMPLE 2. Receives a function as a parameter, and the function receives one parameter only


fun main(){

    // EXAMPLE 4.  Standard High Order functions already implemented in Kotlin

}


