
// EXAMPLE 1. Basic example


// EXAMPLE 2. Two generic parameters

// EXAMPLE 3. Type constraints


fun main() {

}