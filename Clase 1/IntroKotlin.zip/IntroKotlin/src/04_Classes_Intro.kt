
// Class Definition
class Person {
    var name: String = ""
}

// Constructor
class Human(var name:String){

}

fun main() {

    // EXAMPLE 1. Instance of a person

    // EXAMPLE 2. Instance of a person

    //ERROR
    // student = Person()

    //EXAMPLE 3

}