// EXAMPLE 1. Function Declarations


// EXAMPLE 2. Default arguments and named arguments


// EXAMPLE 3. Return Types

// EXAMPLE 4. Single-expression functions


fun main() {

}





