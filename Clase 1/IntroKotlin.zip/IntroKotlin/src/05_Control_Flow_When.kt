fun main() {

    val value = 10

    // EXAMPLE 1. There is not switch in Kotlin
    when (value) {
        15 -> println("Number is 15")
        12 -> println("Number is 12")
        10 -> println("Number is 10")
        else -> println("??")
    }

    // EXAMPLE 2. "when" can be used as expression


    // EXAMPLE 3. "when" is more flexible than switch

}