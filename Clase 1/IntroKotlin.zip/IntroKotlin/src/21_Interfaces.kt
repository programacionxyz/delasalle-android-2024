
// Interfaces
// - Basic definitions
// - Default methods
// - Properties
// - There is not state

class Robot(var firstName:String, var lastName:String)


fun main(){

}