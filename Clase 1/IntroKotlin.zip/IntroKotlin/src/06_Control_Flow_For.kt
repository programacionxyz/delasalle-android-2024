fun main() {

    // EXAMPLE 1.  for and collections

}