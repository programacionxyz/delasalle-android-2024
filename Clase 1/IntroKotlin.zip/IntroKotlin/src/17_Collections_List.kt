

fun main(){

    // EXAMPLE 1. Immutable List


    // EXAMPLE 2. Mutable List

    // EXAMPLE 3. Common operations
    // get, size, contains, filter


}