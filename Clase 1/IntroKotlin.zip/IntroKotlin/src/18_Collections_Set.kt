

fun main(){

    //  A group of unique elements

    // EXAMPLE 1. Immutable Set

    // EXAMPLE 2. Mutable Set


}