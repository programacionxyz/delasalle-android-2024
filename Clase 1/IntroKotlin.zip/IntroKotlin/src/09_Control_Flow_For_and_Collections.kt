import java.util.*


fun main() {

    // EXAMPLE 1. for and collections
    val numbers = listOf(1, 2, 3, 4, 5)
    for (i in numbers) {
        println(i)
    }

    // EXAMPLE 2. for and collections

}