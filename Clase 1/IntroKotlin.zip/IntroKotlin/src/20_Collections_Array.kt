

fun main(){
    val numbers = arrayOf<Int>(9,8,7,6,1, 2, 3, 4, 5)
    println(numbers) // Ljava.lang.Integer;
    println(numbers.contentToString())
}