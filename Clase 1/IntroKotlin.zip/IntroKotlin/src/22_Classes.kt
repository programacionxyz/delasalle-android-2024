// Public and final by default

// EXAMPLE 1. Final by default

// WRONG
// class WrongClass : NotABaseClass()

// EXAMPLE 2. Open class

fun main() {

}