
fun main(){
    print("Enter your name: ")
    val name = readLine()
    println("Hello, $name!") // String Template
}


