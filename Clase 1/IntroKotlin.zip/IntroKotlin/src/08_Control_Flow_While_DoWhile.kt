

fun main(){

    // EXAMPLE 1. While
    var counter = 0
    while (counter != 100) {
        println(counter)
        counter++
    }

    // EXAMPLE 2. Do While
    var counter2 = 0
    do {
        println(counter2)
        counter2++
    } while (counter2 != 100)
}